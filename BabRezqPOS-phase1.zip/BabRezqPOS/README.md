# BabRezq POS — مطعم باب رزق للمشويات

نظام كاشير وإدارة مطعم: C# / .NET 10 / WPF / SQLite / EF Core — عربي RTL، يعمل محليًا بلا إنترنت.

الحالة: **المرحلة 1 (الأساس والدخول)**. التفاصيل والخطة في [`docs/00-التصميم-والمعمارية.md`](docs/00-التصميم-والمعمارية.md).

## ⚠️ لم يُبنَ هذا الكود بعد
كُتب الكود في بيئة بلا .NET SDK ولا Windows، فلم يُترجَم ولم تُشغَّل اختباراته. أول خطوة عندك هي البناء على Windows (أدناه). لو ظهرت أخطاء Compilation أرسلها لي وأصلحها قبل المرحلة 2.

## المتطلبات (Windows 10/11 x64)
- [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0)

## الخطوات
```powershell
# 1) توليد Migration الأولي (مرة واحدة ثم ارفع الملفات الناتجة في src/BabRezq.Data/Migrations)
.\tools\new-migration.ps1 InitialCreate

# 2) بناء + اختبارات
dotnet test tests/BabRezq.Tests

# 3) تشغيل
dotnet run --project src/BabRezq.Desktop

# 4) EXE نهائي: publish\BabRezqPOS.exe
.\tools\build-release.ps1
```
> بدون الخطوة 1 يعمل البرنامج بـ `EnsureCreated` (للتطوير فقط)، ولا يجوز تسليم نسخة تشغيل بدون Migrations.

أو ارفع المجلد إلى GitHub وسيبني **GitHub Actions** (`.github/workflows/build.yml`) على Windows، يشغّل الاختبارات، ويولّد الـ Migration ويعطيك الـ EXE كـ artifacts.

## اختبار المرحلة 1 عمليًا
1. شغّل البرنامج لأول مرة ← تظهر رسالة باسم المستخدم `admin` وكلمة مرور مؤقتة (محفوظة أيضًا في `C:\ProgramData\BabRezqPOS\FIRST_RUN_CREDENTIALS.txt`).
2. سجّل الدخول ← يُطلب تغيير كلمة المرور ← يظهر **كود الاسترجاع** (احفظه، لا تتابع قبل التأكيد).
3. تظهر الشاشة الرئيسية بجدول المنيو (10 أقسام / 47 صنفًا / 84 سعرًا) — راجع الأسعار على ملفك.
4. سجّل خروج، ثم جرّب "نسيت كلمة المرور؟" بالكود.
5. أدخل كلمة مرور خاطئة 5 مرات ← يُقفل الحساب 5 دقائق.
6. طوارئ: `BabRezqPOS.exe --reset-admin` من CMD **كمسؤول** ← كلمة مؤقتة جديدة.
7. السجلات في `C:\ProgramData\BabRezqPOS\Logs`.

## الملفات
| المجلد | المحتوى |
|---|---|
| `src/BabRezq.Domain` | كيانات، `Money`، `PermissionCodes`، `SettingKeys` |
| `src/BabRezq.Data` | `AppDbContext`، Pragma/WAL/FK، `AppPaths`، DI |
| `src/BabRezq.Services` | `AuthService`، `PasswordHasher`، `DatabaseInitializer`، بيانات المنيو، `MenuQueryService` |
| `src/BabRezq.Desktop` | الثيم، الدخول، تغيير كلمة المرور، الاسترجاع، الشاشة الرئيسية |
| `tests/BabRezq.Tests` | 48 حالة اختبار (أمان، دخول، قفل، استرجاع، أسعار المنيو، قيود القاعدة، WAL، FK) |
