using BabRezq.Domain.Common;
using BabRezq.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace BabRezq.Tests;

public class SeedTests
{
    [Fact]
    public async Task Menu_IsImportedFromApprovedPriceList()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        Assert.Equal(10, await ctx.Categories.CountAsync());
        Assert.Equal(47, await ctx.Products.CountAsync());
        Assert.Equal(84, await ctx.ProductPrices.CountAsync());
    }

    [Theory]
    [InlineData("كباب ضاني", "كيلو", 95000)]
    [InlineData("كباب ضاني", "نصف", 47500)]
    [InlineData("كباب ضاني", "ربع", 24500)]
    [InlineData("ريش ضاني", "ربع", 25500)]
    [InlineData("حواوشي موتزاريلا", "كبير", 6000)]
    [InlineData("برجر رزق", "", 9000)]
    [InlineData("فرخة + كيلو كفتة + 1/4 طرب + 2 حواوشي", "", 76000)]
    public async Task Prices_MatchSourceExactly(string product, string variant, long expectedMinor)
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        var price = await ctx.ProductPrices
            .Where(p => p.Product.Name == product && p.VariantName == variant)
            .Select(p => p.PriceMinor).SingleAsync();
        Assert.Equal(expectedMinor, price);
    }

    [Fact]
    public async Task Initialization_IsIdempotent_AndDoesNotReimportDeletedItems()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using (var ctx = db.Db())
        {
            var prices = ctx.ProductPrices.Where(p => p.Product.Name == "لحمة بالبصل");
            ctx.ProductPrices.RemoveRange(prices);
            var product = await ctx.Products.SingleAsync(p => p.Name == "لحمة بالبصل");
            ctx.Products.Remove(product);
            await ctx.SaveChangesAsync();
        }
        await db.InitAsync();
        await using var check = db.Db();
        Assert.Equal(46, await check.Products.CountAsync());
        Assert.Equal(10, await check.Categories.CountAsync());
    }

    [Fact]
    public async Task Settings_TaxAndServiceAreDisabledByDefault_ButConfigurable()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        var settings = await ctx.AppSettings.ToDictionaryAsync(s => s.Key, s => s.Value);
        Assert.Equal("false", settings[SettingKeys.TaxEnabled]);
        Assert.Equal("false", settings[SettingKeys.ServiceEnabled]);
        Assert.Equal("EGP", settings[SettingKeys.Currency]);
        Assert.Equal("مطعم باب رزق للمشويات", settings[SettingKeys.RestaurantName]);
    }

    [Fact]
    public async Task NoDeliveryZonesAreInvented()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        Assert.Equal(0, await ctx.DeliveryZones.CountAsync());
    }
}

public class ConstraintTests
{
    [Fact]
    public async Task Database_UsesWalMode()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        var conn = ctx.Database.GetDbConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "PRAGMA journal_mode;";
        Assert.Equal("wal", (string?)await cmd.ExecuteScalarAsync());
    }

    [Fact]
    public async Task ForeignKeys_AreEnforced()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        ctx.Users.Add(new User { Username = "ghost", FullName = "x", PasswordHash = "h", RoleId = 9999 });
        await Assert.ThrowsAsync<DbUpdateException>(() => ctx.SaveChangesAsync());
    }

    [Fact]
    public async Task Username_IsUnique_CaseInsensitive()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        var roleId = (await ctx.Roles.FirstAsync()).Id;
        ctx.Users.Add(new User { Username = "ADMIN", FullName = "dup", PasswordHash = "h", RoleId = roleId });
        await Assert.ThrowsAsync<DbUpdateException>(() => ctx.SaveChangesAsync());
    }

    [Fact]
    public async Task DuplicateVariantForSameProduct_IsRejected()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        var product = await ctx.Products.FirstAsync();
        var existing = await ctx.ProductPrices.FirstAsync(p => p.ProductId == product.Id);
        ctx.ProductPrices.Add(new ProductPrice { ProductId = product.Id, VariantName = existing.VariantName, PriceMinor = 1 });
        await Assert.ThrowsAsync<DbUpdateException>(() => ctx.SaveChangesAsync());
    }

    [Fact]
    public async Task Timestamps_AreStampedOnInsertAndUpdate()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        var category = await ctx.Categories.FirstAsync();
        Assert.NotEqual(default, category.CreatedAtUtc);
        Assert.Null(category.UpdatedAtUtc);
        category.Name += " ";
        await ctx.SaveChangesAsync();
        Assert.NotNull(category.UpdatedAtUtc);
    }

    [Fact]
    public async Task PaymentMethods_CashOpensDrawer()
    {
        using var db = new TestDb();
        await db.InitAsync();
        await using var ctx = db.Db();
        Assert.True((await ctx.PaymentMethods.SingleAsync(p => p.Code == "CASH")).OpensDrawer);
        Assert.False((await ctx.PaymentMethods.SingleAsync(p => p.Code == "CARD")).OpensDrawer);
    }
}
