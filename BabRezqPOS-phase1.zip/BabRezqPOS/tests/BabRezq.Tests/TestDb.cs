using BabRezq.Data;
using BabRezq.Data.Infrastructure;
using BabRezq.Services.Auth;
using BabRezq.Services.Security;
using BabRezq.Services.Seeding;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging.Abstractions;

namespace BabRezq.Tests;

public sealed class TestTime : TimeProvider
{
    public DateTimeOffset Now { get; set; } = new(2026, 1, 1, 12, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Now;
}

/// <summary>قاعدة SQLite مؤقتة على ملف حقيقي (لاختبار WAL والقيود كما في الإنتاج).</summary>
public sealed class TestDb : IDisposable
{
    private readonly ServiceProvider _provider;

    public string Path { get; } = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"babrezq-test-{Guid.NewGuid():N}.db");
    public IDbContextFactory<AppDbContext> Factory { get; }
    public IPasswordHasher Hasher { get; } = new Pbkdf2PasswordHasher(1000); // أسرع في الاختبارات فقط
    public TestTime Time { get; } = new();

    public TestDb()
    {
        var services = new ServiceCollection();
        services.AddBabRezqData(Path);
        _provider = services.BuildServiceProvider();
        Factory = _provider.GetRequiredService<IDbContextFactory<AppDbContext>>();
    }

    public DatabaseInitializer Initializer() =>
        new(Factory, Hasher, NullLogger<DatabaseInitializer>.Instance);

    public Task<InitializationResult> InitAsync() => Initializer().InitializeAsync();

    public AuthService Auth() => new(Factory, Hasher, NullLogger<AuthService>.Instance, Time);

    public AppDbContext Db() => Factory.CreateDbContext();

    public void Dispose()
    {
        _provider.Dispose();
        SqliteConnection.ClearAllPools();
        foreach (var suffix in new[] { "", "-wal", "-shm" })
        {
            try { File.Delete(Path + suffix); } catch (IOException) { }
        }
    }
}
