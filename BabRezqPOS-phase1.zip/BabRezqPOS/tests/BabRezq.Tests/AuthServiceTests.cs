using BabRezq.Data;
using BabRezq.Domain.Common;
using BabRezq.Domain.Entities;
using BabRezq.Services.Auth;
using BabRezq.Services.Seeding;
using Microsoft.EntityFrameworkCore;

namespace BabRezq.Tests;

public class AuthServiceTests
{
    private static async Task<(TestDb Db, string Temp)> NewInitializedAsync()
    {
        var db = new TestDb();
        var init = await db.InitAsync();
        Assert.NotNull(init.FirstRunTempPassword);
        return (db, init.FirstRunTempPassword!);
    }

    [Fact]
    public async Task FirstRun_CreatesManager_WithTempPassword_AndMustChange()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        await using var ctx = db.Db();
        var user = await ctx.Users.SingleAsync();
        Assert.Equal("admin", user.Username);
        Assert.True(user.MustChangePassword);
        Assert.DoesNotContain(temp, user.PasswordHash); // لا نص صريح
        Assert.Equal(10, temp.Length);
    }

    [Fact]
    public async Task SecondInitialization_DoesNotCreateAnotherManager()
    {
        var (db, _) = await NewInitializedAsync();
        using var guard = db;
        var second = await db.InitAsync();
        Assert.Null(second.FirstRunTempPassword);
        await using var ctx = db.Db();
        Assert.Equal(1, await ctx.Users.CountAsync());
    }

    [Fact]
    public async Task Login_WithTempPassword_Succeeds_WithAllPermissions_AndMustChange()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var result = await db.Auth().LoginAsync("ADMIN", temp); // اسم المستخدم غير حساس لحالة الأحرف
        Assert.Equal(LoginStatus.Success, result.Status);
        Assert.True(result.User!.MustChangePassword);
        Assert.Equal(PermissionCodes.All.Count, result.User.Permissions.Count);
        Assert.True(result.User.Has(PermissionCodes.UsersManage));
    }

    [Fact]
    public async Task Login_WrongPassword_Fails_AndIsLogged()
    {
        var (db, _) = await NewInitializedAsync();
        using var guard = db;
        var result = await db.Auth().LoginAsync("admin", "wrong-password");
        Assert.Equal(LoginStatus.InvalidCredentials, result.Status);
        await using var ctx = db.Db();
        Assert.Equal(1, await ctx.LoginHistories.CountAsync(h => h.EventType == LoginEventType.FailedLogin));
    }

    [Fact]
    public async Task Login_UnknownUser_Fails()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var result = await db.Auth().LoginAsync("nobody", temp);
        Assert.Equal(LoginStatus.InvalidCredentials, result.Status);
    }

    [Fact]
    public async Task Login_LocksAfterFiveFailures_ThenUnlocksAfterDuration()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var auth = db.Auth();
        for (var i = 0; i < AuthService.MaxFailedAttempts; i++)
            await auth.LoginAsync("admin", "wrong-password");

        var locked = await auth.LoginAsync("admin", temp); // حتى الصحيحة تُرفض أثناء القفل
        Assert.Equal(LoginStatus.LockedOut, locked.Status);

        db.Time.Now = db.Time.Now + AuthService.LockoutDuration + TimeSpan.FromSeconds(1);
        var ok = await auth.LoginAsync("admin", temp);
        Assert.Equal(LoginStatus.Success, ok.Status);
    }

    [Fact]
    public async Task Login_InactiveUser_IsRejected()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        await using (var ctx = db.Db())
        {
            var u = await ctx.Users.SingleAsync();
            u.IsActive = false;
            await ctx.SaveChangesAsync();
        }
        Assert.Equal(LoginStatus.Inactive, (await db.Auth().LoginAsync("admin", temp)).Status);
    }

    [Fact]
    public async Task ChangePassword_ClearsMustChange_IssuesRecoveryCode_AndOldPasswordStopsWorking()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var auth = db.Auth();
        var login = await auth.LoginAsync("admin", temp);

        var change = await auth.ChangePasswordAsync(login.User!.Id, temp, "NewPass123");
        Assert.Equal(PasswordChangeStatus.Success, change.Status);
        Assert.NotNull(change.RecoveryCode);

        Assert.Equal(LoginStatus.InvalidCredentials, (await auth.LoginAsync("admin", temp)).Status);
        var again = await auth.LoginAsync("admin", "NewPass123");
        Assert.Equal(LoginStatus.Success, again.Status);
        Assert.False(again.User!.MustChangePassword);

        // تغيير لاحق لا يصدر كود جديدًا
        var second = await auth.ChangePasswordAsync(login.User.Id, "NewPass123", "Another456");
        Assert.Equal(PasswordChangeStatus.Success, second.Status);
        Assert.Null(second.RecoveryCode);
    }

    [Fact]
    public async Task ChangePassword_RejectsWrongCurrent_AndWeak()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var auth = db.Auth();
        var id = (await auth.LoginAsync("admin", temp)).User!.Id;

        Assert.Equal(PasswordChangeStatus.WrongCurrentPassword,
            (await auth.ChangePasswordAsync(id, "nope", "NewPass123")).Status);
        Assert.Equal(PasswordChangeStatus.PolicyViolation,
            (await auth.ChangePasswordAsync(id, temp, "weak")).Status);
    }

    [Fact]
    public async Task RecoveryCode_ResetsPassword_RotatesCode_AndOldCodeFails()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var auth = db.Auth();
        var id = (await auth.LoginAsync("admin", temp)).User!.Id;
        var code = (await auth.ChangePasswordAsync(id, temp, "NewPass123")).RecoveryCode!;

        var reset = await auth.ResetWithRecoveryCodeAsync("admin", code.ToLowerInvariant().Replace("-", " "), "Forgot789");
        Assert.Equal(RecoveryStatus.Success, reset.Status);
        Assert.NotNull(reset.NewRecoveryCode);
        Assert.NotEqual(code, reset.NewRecoveryCode);

        Assert.Equal(LoginStatus.Success, (await auth.LoginAsync("admin", "Forgot789")).Status);
        Assert.Equal(RecoveryStatus.InvalidCredentials,
            (await auth.ResetWithRecoveryCodeAsync("admin", code, "Third12345")).Status);
    }

    [Fact]
    public async Task RecoveryCode_WrongAttempts_CountTowardLockout()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var auth = db.Auth();
        var id = (await auth.LoginAsync("admin", temp)).User!.Id;
        var code = (await auth.ChangePasswordAsync(id, temp, "NewPass123")).RecoveryCode!;

        for (var i = 0; i < AuthService.MaxFailedAttempts; i++)
            await auth.ResetWithRecoveryCodeAsync("admin", "AAAA-AAAA-AAAA-AAAA", "Forgot789");

        Assert.Equal(RecoveryStatus.LockedOut,
            (await auth.ResetWithRecoveryCodeAsync("admin", code, "Forgot789")).Status);
    }

    [Fact]
    public async Task ResetPrimaryManager_IssuesNewTempPassword_AndForcesChange()
    {
        var (db, temp) = await NewInitializedAsync();
        using var guard = db;
        var auth = db.Auth();
        var id = (await auth.LoginAsync("admin", temp)).User!.Id;
        await auth.ChangePasswordAsync(id, temp, "NewPass123");

        var reset = await db.Initializer().ResetPrimaryManagerAsync();
        Assert.NotNull(reset);
        Assert.Equal(LoginStatus.InvalidCredentials, (await auth.LoginAsync("admin", "NewPass123")).Status);
        var login = await auth.LoginAsync("admin", reset!.TempPassword);
        Assert.Equal(LoginStatus.Success, login.Status);
        Assert.True(login.User!.MustChangePassword);
    }

    [Fact]
    public async Task Cashier_HasOnlyDefaultPermissions()
    {
        var (db, _) = await NewInitializedAsync();
        using var guard = db;
        await using var ctx = db.Db();
        var codes = await ctx.RolePermissions
            .Where(rp => rp.Role.Name == DatabaseInitializer.CashierRoleName)
            .Select(rp => rp.Permission.Code).ToListAsync();
        Assert.Equal(PermissionCodes.CashierDefaults.OrderBy(c => c), codes.OrderBy(c => c));
        Assert.DoesNotContain(PermissionCodes.ReturnsCreate, codes);
    }
}
