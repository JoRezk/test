using BabRezq.Domain.Common;
using BabRezq.Services.Security;

namespace BabRezq.Tests;

public class MoneyTests
{
    [Theory]
    [InlineData(0, "0 ج.م")]
    [InlineData(100, "1 ج.م")]
    [InlineData(100000, "1,000 ج.م")]
    [InlineData(1250, "12.50 ج.م")]
    [InlineData(5, "0.05 ج.م")]
    [InlineData(-2550, "-25.50 ج.م")]
    public void Format_UsesEgpWithoutFloatingPoint(long minor, string expected) =>
        Assert.Equal(expected, Money.Format(minor));

    [Fact]
    public void ToMinor_RoundsHalfAwayFromZero()
    {
        Assert.Equal(1005, Money.ToMinor(10.05m));
        Assert.Equal(1001, Money.ToMinor(10.005m));
        Assert.Equal(25500, Money.ToMinor(255m));
    }

    [Fact]
    public void ApplyPercent_IsExactInMinorUnits()
    {
        Assert.Equal(1400, Money.ApplyPercent(10000, 14m));
        Assert.Equal(0, Money.ApplyPercent(10000, 0m));
        Assert.Equal(1, Money.ApplyPercent(5, 14m)); // 0.7 -> 1
    }
}

public class PasswordHasherTests
{
    private readonly Pbkdf2PasswordHasher _hasher = new(1000);

    [Fact]
    public void Hash_IsSalted_AndNeverContainsPlaintext()
    {
        var a = _hasher.Hash("Secret123");
        var b = _hasher.Hash("Secret123");
        Assert.NotEqual(a, b);
        Assert.DoesNotContain("Secret123", a);
        Assert.StartsWith("PBKDF2-SHA256$", a);
    }

    [Fact]
    public void Verify_AcceptsCorrect_RejectsWrongAndMalformed()
    {
        var h = _hasher.Hash("Secret123");
        Assert.True(_hasher.Verify("Secret123", h));
        Assert.False(_hasher.Verify("secret123", h));
        Assert.False(_hasher.Verify("Secret123", "garbage"));
        Assert.False(_hasher.Verify("Secret123", "PBKDF2-SHA256$x$y$z"));
        Assert.False(_hasher.Verify("", h));
    }
}

public class PasswordPolicyTests
{
    [Theory]
    [InlineData("short1", false)]
    [InlineData("onlyletters", false)]
    [InlineData("12345678", false)]
    [InlineData("Good1234", true)]
    [InlineData("كلمة12345", true)]
    public void Validate_EnforcesLengthLettersAndDigits(string password, bool ok) =>
        Assert.Equal(ok, PasswordPolicy.Validate(password) is null);

    [Fact]
    public void Validate_RejectsUsernameAsPassword() =>
        Assert.NotNull(PasswordPolicy.Validate("admin1234", "ADMIN1234"));
}

public class SecretGeneratorTests
{
    [Fact]
    public void RecoveryCode_HasExpectedShape_AndNormalizes()
    {
        var code = SecretGenerator.RecoveryCode();
        Assert.Matches("^[A-Z2-9]{4}(-[A-Z2-9]{4}){3}$", code);
        Assert.Equal(16, SecretGenerator.NormalizeRecoveryCode(code).Length);
        Assert.Equal("ABCD1234", SecretGenerator.NormalizeRecoveryCode(" abcd-1234 "));
    }

    [Fact]
    public void TempPassword_Has10Chars_AndDiffers() =>
        Assert.NotEqual(SecretGenerator.TempPassword(), SecretGenerator.TempPassword());
}
