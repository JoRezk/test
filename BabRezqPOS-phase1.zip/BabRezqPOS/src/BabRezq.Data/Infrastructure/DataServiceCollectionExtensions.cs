using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace BabRezq.Data.Infrastructure;

public static class DataServiceCollectionExtensions
{
    public static string BuildConnectionString(string dbPath) =>
        new SqliteConnectionStringBuilder
        {
            DataSource = dbPath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            ForeignKeys = true
        }.ToString();

    public static IServiceCollection AddBabRezqData(this IServiceCollection services, string dbPath)
    {
        var connectionString = BuildConnectionString(dbPath);
        var interceptor = new SqlitePragmaInterceptor();
        services.AddDbContextFactory<AppDbContext>(o =>
        {
            o.UseSqlite(connectionString);
            o.AddInterceptors(interceptor);
        });
        return services;
    }
}
