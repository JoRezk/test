namespace BabRezq.Data.Infrastructure;

public sealed record AppPaths(string DataDir)
{
    public const string DataDirEnvironmentVariable = "BABREZQ_DATA_DIR";

    public string DbPath => Path.Combine(DataDir, "BabRezqPOS.db");
    public string LogsDir => Path.Combine(DataDir, "Logs");
    public string BackupsDir => Path.Combine(DataDir, "Backups");
    public string FirstRunFile => Path.Combine(DataDir, "FIRST_RUN_CREDENTIALS.txt");

    /// <summary>
    /// الترتيب: متغير البيئة (للاختبار) ← ProgramData\BabRezqPOS ← LocalAppData\BabRezqPOS (إذا لم تتوفر صلاحية الكتابة).
    /// </summary>
    public static AppPaths Resolve()
    {
        var candidates = new List<string>();
        var fromEnv = Environment.GetEnvironmentVariable(DataDirEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(fromEnv)) candidates.Add(fromEnv);
        candidates.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "BabRezqPOS"));
        candidates.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BabRezqPOS"));

        foreach (var dir in candidates)
        {
            if (TryPrepare(dir)) return new AppPaths(dir);
        }
        throw new IOException("تعذر إنشاء مجلد بيانات البرنامج: لا توجد صلاحية كتابة.");
    }

    private static bool TryPrepare(string dir)
    {
        try
        {
            Directory.CreateDirectory(dir);
            Directory.CreateDirectory(Path.Combine(dir, "Logs"));
            Directory.CreateDirectory(Path.Combine(dir, "Backups"));
            var probe = Path.Combine(dir, $".write-test-{Guid.NewGuid():N}");
            File.WriteAllText(probe, "x");
            File.Delete(probe);
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }
}
