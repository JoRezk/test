using BabRezq.Data;
using Microsoft.EntityFrameworkCore;

namespace BabRezq.Services.Menu;

public sealed record MenuRow(string Category, string Product, string Variant, long PriceMinor, bool Active);

public interface IMenuQueryService
{
    Task<IReadOnlyList<MenuRow>> GetFlatMenuAsync(CancellationToken ct = default);
}

public sealed class MenuQueryService(IDbContextFactory<AppDbContext> factory) : IMenuQueryService
{
    public async Task<IReadOnlyList<MenuRow>> GetFlatMenuAsync(CancellationToken ct = default)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        return await db.ProductPrices.AsNoTracking()
            .OrderBy(p => p.Product.Category.SortOrder)
            .ThenBy(p => p.Product.SortOrder)
            .ThenBy(p => p.SortOrder)
            .Select(p => new MenuRow(
                p.Product.Category.Name,
                p.Product.Name,
                p.VariantName,
                p.PriceMinor,
                p.IsActive && p.Product.IsActive && p.Product.Category.IsActive))
            .ToListAsync(ct);
    }
}
