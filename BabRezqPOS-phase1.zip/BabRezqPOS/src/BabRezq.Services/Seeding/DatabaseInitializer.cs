using BabRezq.Data;
using BabRezq.Domain.Common;
using BabRezq.Domain.Entities;
using BabRezq.Services.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BabRezq.Services.Seeding;

public sealed record InitializationResult(string? FirstRunUsername, string? FirstRunTempPassword);

public sealed record ManagerResetResult(string Username, string TempPassword);

/// <summary>تهيئة قاعدة البيانات عند التشغيل: Migrations + WAL + بيانات أولية (الصلاحيات، الأدوار، الإعدادات، المنيو، المدير).</summary>
public sealed class DatabaseInitializer(
    IDbContextFactory<AppDbContext> factory,
    IPasswordHasher hasher,
    ILogger<DatabaseInitializer> logger)
{
    public const string ManagerRoleName = "Manager";
    public const string CashierRoleName = "Cashier";
    public const string DefaultManagerUsername = "admin";

    public async Task<InitializationResult> InitializeAsync(CancellationToken ct = default)
    {
        await using var db = await factory.CreateDbContextAsync(ct);

        if (db.Database.GetMigrations().Any())
        {
            await db.Database.MigrateAsync(ct);
        }
        else
        {
            // لم يتم توليد Migrations بعد (بيئة تطوير/اختبار فقط). الإصدار النهائي يجب أن يحتوي Migrations.
            logger.LogWarning("No EF migrations found; falling back to EnsureCreated (development only).");
            await db.Database.EnsureCreatedAsync(ct);
        }

        await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode=WAL;", ct);

        await SeedPermissionsAndRolesAsync(db, ct);
        await SeedSettingsAsync(db, ct);
        await SeedPaymentMethodsAsync(db, ct);
        await SeedMenuAsync(db, ct);
        return await EnsureFirstManagerAsync(db, ct);
    }

    /// <summary>
    /// إعادة تعيين كلمة مرور المدير الرئيسي إلى كلمة مؤقتة جديدة (تُغيَّر عند الدخول التالي).
    /// مخصصة للاستخدام عبر "--reset-admin" بصلاحيات مسؤول Windows فقط.
    /// </summary>
    public async Task<ManagerResetResult?> ResetPrimaryManagerAsync(CancellationToken ct = default)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var user = await db.Users.FirstOrDefaultAsync(u => u.Username == DefaultManagerUsername, ct)
                   ?? await db.Users.Include(u => u.Role)
                       .Where(u => u.Role.Name == ManagerRoleName)
                       .OrderBy(u => u.Id).FirstOrDefaultAsync(ct);
        if (user is null) return null;

        var temp = SecretGenerator.TempPassword();
        user.PasswordHash = hasher.Hash(temp);
        user.MustChangePassword = true;
        user.IsActive = true;
        user.FailedLoginCount = 0;
        user.LockoutEndUtc = null;
        user.RecoveryCodeHash = null; // يُصدر كود جديد عند تغيير كلمة المرور
        db.AuditLogs.Add(new AuditLog
        {
            AtUtc = DateTime.UtcNow, UserId = user.Id, Action = "user.password_reset_by_windows_admin",
            EntityName = nameof(User), EntityId = user.Id.ToString()
        });
        await db.SaveChangesAsync(ct);
        logger.LogWarning("Primary manager password reset via Windows administrator command");
        return new ManagerResetResult(user.Username, temp);
    }

    private static async Task SeedPermissionsAndRolesAsync(AppDbContext db, CancellationToken ct)
    {
        var existingCodes = await db.Permissions.Select(p => p.Code).ToListAsync(ct);
        foreach (var (code, name, group) in PermissionCodes.All.Where(p => !existingCodes.Contains(p.Code)))
            db.Permissions.Add(new Permission { Code = code, DisplayName = name, GroupName = group });
        await db.SaveChangesAsync(ct);

        var manager = await db.Roles.Include(r => r.RolePermissions).FirstOrDefaultAsync(r => r.Name == ManagerRoleName, ct);
        if (manager is null)
        {
            manager = new Role { Name = ManagerRoleName, DisplayName = "مدير", IsSystem = true };
            db.Roles.Add(manager);
        }

        var cashier = await db.Roles.Include(r => r.RolePermissions).FirstOrDefaultAsync(r => r.Name == CashierRoleName, ct);
        var cashierIsNew = cashier is null;
        if (cashier is null)
        {
            cashier = new Role { Name = CashierRoleName, DisplayName = "كاشير", IsSystem = true };
            db.Roles.Add(cashier);
        }
        await db.SaveChangesAsync(ct);

        var permissions = await db.Permissions.ToListAsync(ct);

        // المدير يملك دائمًا كل الصلاحيات (ومنها أي صلاحيات تُضاف في إصدارات لاحقة).
        var managerHas = manager.RolePermissions.Select(rp => rp.PermissionId).ToHashSet();
        foreach (var p in permissions.Where(p => !managerHas.Contains(p.Id)))
            db.RolePermissions.Add(new RolePermission { RoleId = manager.Id, PermissionId = p.Id });

        // الكاشير: صلاحيات افتراضية عند الإنشاء فقط، حتى لا نلغي تعديلات المدير لاحقًا.
        if (cashierIsNew)
        {
            foreach (var p in permissions.Where(p => PermissionCodes.CashierDefaults.Contains(p.Code)))
                db.RolePermissions.Add(new RolePermission { RoleId = cashier.Id, PermissionId = p.Id });
        }
        await db.SaveChangesAsync(ct);
    }

    private static async Task SeedSettingsAsync(AppDbContext db, CancellationToken ct)
    {
        var defaults = new Dictionary<string, string>
        {
            [SettingKeys.RestaurantName] = "مطعم باب رزق للمشويات",
            [SettingKeys.RestaurantAddress] = "",
            [SettingKeys.RestaurantPhone] = "",
            [SettingKeys.Currency] = "EGP",
            [SettingKeys.TaxEnabled] = "false",
            [SettingKeys.TaxName] = "ضريبة القيمة المضافة",
            [SettingKeys.TaxRatePercent] = "0",
            [SettingKeys.ServiceEnabled] = "false",
            [SettingKeys.ServiceRatePercent] = "0",
            [SettingKeys.ReceiptFooter] = "شكرًا لزيارتكم",
        };
        var existing = await db.AppSettings.Select(s => s.Key).ToListAsync(ct);
        foreach (var (key, value) in defaults.Where(d => !existing.Contains(d.Key)))
            db.AppSettings.Add(new AppSetting { Key = key, Value = value, UpdatedAtUtc = DateTime.UtcNow });
        await db.SaveChangesAsync(ct);
    }

    private static async Task SeedPaymentMethodsAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.PaymentMethods.AnyAsync(ct)) return;
        db.PaymentMethods.Add(new PaymentMethod { Code = "CASH", Name = "نقدي", IsSystem = true, OpensDrawer = true });
        db.PaymentMethods.Add(new PaymentMethod { Code = "CARD", Name = "بطاقة", IsSystem = true, OpensDrawer = false });
        await db.SaveChangesAsync(ct);
    }

    private async Task SeedMenuAsync(AppDbContext db, CancellationToken ct)
    {
        // علامة MenuSeeded تمنع إعادة الاستيراد لاحقًا حتى لو حذف المدير أصنافًا.
        if (await db.AppSettings.AnyAsync(s => s.Key == SettingKeys.MenuSeeded, ct)) return;
        if (await db.Categories.AnyAsync(ct)) return;

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var categoryOrder = 0;
        var productCounter = 0;
        foreach (var seedCategory in MenuSeedData.Categories)
        {
            var category = new Category { Name = seedCategory.Name, SortOrder = ++categoryOrder };
            var itemOrder = 0;
            foreach (var item in seedCategory.Items)
            {
                var product = new Product
                {
                    Category = category,
                    Code = $"P{++productCounter:000}",
                    Name = item.Name,
                    Notes = item.Notes,
                    SortOrder = ++itemOrder
                };
                var priceOrder = 0;
                foreach (var (variant, egp) in item.Prices)
                {
                    product.Prices.Add(new ProductPrice
                    {
                        VariantName = variant,
                        PriceMinor = Money.ToMinor(egp),
                        SortOrder = ++priceOrder
                    });
                }
                category.Products.Add(product);
            }
            db.Categories.Add(category);
        }
        db.AppSettings.Add(new AppSetting { Key = SettingKeys.MenuSeeded, Value = "true", UpdatedAtUtc = DateTime.UtcNow });
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        logger.LogInformation("Seeded menu: {Categories} categories, {Products} products", categoryOrder, productCounter);
    }

    private async Task<InitializationResult> EnsureFirstManagerAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.Users.AnyAsync(ct)) return new InitializationResult(null, null);

        var role = await db.Roles.FirstAsync(r => r.Name == ManagerRoleName, ct);
        var temp = SecretGenerator.TempPassword();
        db.Users.Add(new User
        {
            Username = DefaultManagerUsername,
            FullName = "المدير",
            PasswordHash = hasher.Hash(temp),
            RoleId = role.Id,
            IsActive = true,
            MustChangePassword = true
        });
        await db.SaveChangesAsync(ct);
        logger.LogInformation("Created default manager account with temporary password");
        return new InitializationResult(DefaultManagerUsername, temp);
    }
}
