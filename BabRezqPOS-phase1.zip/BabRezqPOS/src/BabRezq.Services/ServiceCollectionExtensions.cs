using BabRezq.Services.Auth;
using BabRezq.Services.Menu;
using BabRezq.Services.Security;
using BabRezq.Services.Seeding;
using Microsoft.Extensions.DependencyInjection;

namespace BabRezq.Services;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddBabRezqServices(this IServiceCollection services)
    {
        services.AddSingleton(TimeProvider.System);
        services.AddSingleton<IPasswordHasher>(_ => new Pbkdf2PasswordHasher());
        services.AddSingleton<DatabaseInitializer>();
        services.AddSingleton<IAuthService, AuthService>();
        services.AddSingleton<IMenuQueryService, MenuQueryService>();
        return services;
    }
}
