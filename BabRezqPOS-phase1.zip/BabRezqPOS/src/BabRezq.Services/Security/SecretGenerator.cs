using System.Security.Cryptography;
using System.Text;

namespace BabRezq.Services.Security;

public static class SecretGenerator
{
    // بدون الحروف والأرقام المتشابهة (0/O و1/I)
    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    private static string Random(int length)
    {
        var sb = new StringBuilder(length);
        for (var i = 0; i < length; i++)
            sb.Append(Alphabet[RandomNumberGenerator.GetInt32(Alphabet.Length)]);
        return sb.ToString();
    }

    /// <summary>كلمة مرور مؤقتة من 10 خانات.</summary>
    public static string TempPassword() => Random(10);

    /// <summary>كود استرجاع بصيغة XXXX-XXXX-XXXX-XXXX.</summary>
    public static string RecoveryCode()
    {
        var raw = Random(16);
        return $"{raw[..4]}-{raw[4..8]}-{raw[8..12]}-{raw[12..]}";
    }

    /// <summary>توحيد شكل الكود قبل التشفير/المقارنة (حذف الشرطات والمسافات وتحويل لحروف كبيرة).</summary>
    public static string NormalizeRecoveryCode(string? code) =>
        new string((code ?? string.Empty).Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
}
