using System.Security.Cryptography;

namespace BabRezq.Services.Security;

public interface IPasswordHasher
{
    string Hash(string secret);
    bool Verify(string secret, string stored);
}

/// <summary>PBKDF2-SHA256 مع salt عشوائي لكل كلمة مرور. الصيغة: PBKDF2-SHA256$iterations$salt$hash</summary>
public sealed class Pbkdf2PasswordHasher(int iterations = Pbkdf2PasswordHasher.DefaultIterations) : IPasswordHasher
{
    public const int DefaultIterations = 600_000;
    private const string Scheme = "PBKDF2-SHA256";
    private const int SaltSize = 16;
    private const int KeySize = 32;

    public string Hash(string secret)
    {
        ArgumentException.ThrowIfNullOrEmpty(secret);
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var key = Rfc2898DeriveBytes.Pbkdf2(secret, salt, iterations, HashAlgorithmName.SHA256, KeySize);
        return $"{Scheme}${iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(key)}";
    }

    public bool Verify(string secret, string stored)
    {
        if (string.IsNullOrEmpty(secret) || string.IsNullOrEmpty(stored)) return false;
        var parts = stored.Split('$');
        if (parts.Length != 4 || parts[0] != Scheme) return false;
        if (!int.TryParse(parts[1], out var iter) || iter <= 0) return false;
        try
        {
            var salt = Convert.FromBase64String(parts[2]);
            var expected = Convert.FromBase64String(parts[3]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(secret, salt, iter, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch (FormatException)
        {
            return false;
        }
    }
}
