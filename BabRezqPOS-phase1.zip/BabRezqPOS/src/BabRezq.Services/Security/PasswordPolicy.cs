namespace BabRezq.Services.Security;

public static class PasswordPolicy
{
    public const int MinLength = 8;

    /// <returns>رسالة الخطأ بالعربية، أو null إذا كانت كلمة المرور مقبولة.</returns>
    public static string? Validate(string? password, string? username = null)
    {
        if (string.IsNullOrEmpty(password) || password.Length < MinLength)
            return $"كلمة المرور يجب ألا تقل عن {MinLength} خانات.";
        if (!password.Any(char.IsLetter) || !password.Any(char.IsDigit))
            return "كلمة المرور يجب أن تحتوي على حروف وأرقام.";
        if (!string.IsNullOrEmpty(username) &&
            string.Equals(password, username, StringComparison.OrdinalIgnoreCase))
            return "كلمة المرور يجب ألا تطابق اسم المستخدم.";
        return null;
    }
}
