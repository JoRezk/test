namespace BabRezq.Services.Auth;

public sealed record AuthenticatedUser(
    int Id,
    string Username,
    string FullName,
    string RoleName,
    bool MustChangePassword,
    IReadOnlySet<string> Permissions)
{
    public bool Has(string permissionCode) => Permissions.Contains(permissionCode);
}

public enum LoginStatus { Success, InvalidCredentials, LockedOut, Inactive }

public sealed record LoginResult(LoginStatus Status, AuthenticatedUser? User = null, TimeSpan? LockoutRemaining = null);

public enum PasswordChangeStatus { Success, WrongCurrentPassword, PolicyViolation, SameAsCurrent, UserNotFound }

/// <param name="RecoveryCode">يُرجَع مرة واحدة فقط عند أول تغيير لكلمة المرور؛ يجب عرضه للمستخدم وحفظه.</param>
public sealed record PasswordChangeResult(PasswordChangeStatus Status, string? RecoveryCode = null, string? Message = null);

public enum RecoveryStatus { Success, InvalidCredentials, LockedOut, PolicyViolation }

public sealed record RecoveryResult(RecoveryStatus Status, string? NewRecoveryCode = null, string? Message = null, TimeSpan? LockoutRemaining = null);
