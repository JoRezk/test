using BabRezq.Data;
using BabRezq.Domain.Entities;
using BabRezq.Services.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BabRezq.Services.Auth;

public sealed class AuthService(
    IDbContextFactory<AppDbContext> factory,
    IPasswordHasher hasher,
    ILogger<AuthService> logger,
    TimeProvider time) : IAuthService
{
    public const int MaxFailedAttempts = 5;
    public static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(5);

    private readonly Lazy<string> _dummyHash = new(() => hasher.Hash("dummy-password-for-timing"));

    private DateTime Now => time.GetUtcNow().UtcDateTime;

    public async Task<LoginResult> LoginAsync(string username, string password, CancellationToken ct = default)
    {
        var name = (username ?? string.Empty).Trim();
        await using var db = await factory.CreateDbContextAsync(ct);

        var user = await db.Users
            .Include(u => u.Role).ThenInclude(r => r.RolePermissions).ThenInclude(rp => rp.Permission)
            .FirstOrDefaultAsync(u => u.Username == name, ct);

        if (user is null)
        {
            hasher.Verify(password ?? string.Empty, _dummyHash.Value); // تقليل فرق التوقيت
            AddHistory(db, null, name, LoginEventType.FailedLogin, "اسم مستخدم غير موجود");
            await db.SaveChangesAsync(ct);
            return new LoginResult(LoginStatus.InvalidCredentials);
        }

        if (!user.IsActive)
        {
            AddHistory(db, user.Id, user.Username, LoginEventType.FailedLogin, "حساب موقوف");
            await db.SaveChangesAsync(ct);
            return new LoginResult(LoginStatus.Inactive);
        }

        if (IsLocked(user, out var remaining))
            return new LoginResult(LoginStatus.LockedOut, LockoutRemaining: remaining);

        if (!hasher.Verify(password ?? string.Empty, user.PasswordHash))
        {
            var lockedNow = RegisterFailure(db, user, "كلمة مرور خاطئة");
            await db.SaveChangesAsync(ct);
            return lockedNow
                ? new LoginResult(LoginStatus.LockedOut, LockoutRemaining: LockoutDuration)
                : new LoginResult(LoginStatus.InvalidCredentials);
        }

        user.FailedLoginCount = 0;
        user.LockoutEndUtc = null;
        user.LastLoginAtUtc = Now;
        AddHistory(db, user.Id, user.Username, LoginEventType.Login, null);
        await db.SaveChangesAsync(ct);

        logger.LogInformation("User {Username} logged in", user.Username);
        var permissions = user.Role.RolePermissions.Select(rp => rp.Permission.Code).ToHashSet();
        return new LoginResult(LoginStatus.Success,
            new AuthenticatedUser(user.Id, user.Username, user.FullName, user.Role.DisplayName,
                user.MustChangePassword, permissions));
    }

    public async Task LogoutAsync(int userId, CancellationToken ct = default)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var user = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == userId, ct);
        if (user is null) return;
        AddHistory(db, user.Id, user.Username, LoginEventType.Logout, null);
        await db.SaveChangesAsync(ct);
    }

    public async Task<PasswordChangeResult> ChangePasswordAsync(int userId, string currentPassword,
        string newPassword, CancellationToken ct = default)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var user = await db.Users.FirstOrDefaultAsync(u => u.Id == userId, ct);
        if (user is null) return new PasswordChangeResult(PasswordChangeStatus.UserNotFound);

        if (!hasher.Verify(currentPassword ?? string.Empty, user.PasswordHash))
            return new PasswordChangeResult(PasswordChangeStatus.WrongCurrentPassword,
                Message: "كلمة المرور الحالية غير صحيحة.");

        var policy = PasswordPolicy.Validate(newPassword, user.Username);
        if (policy is not null)
            return new PasswordChangeResult(PasswordChangeStatus.PolicyViolation, Message: policy);

        if (newPassword == currentPassword)
            return new PasswordChangeResult(PasswordChangeStatus.SameAsCurrent,
                Message: "كلمة المرور الجديدة يجب أن تختلف عن الحالية.");

        user.PasswordHash = hasher.Hash(newPassword);

        string? recoveryCode = null;
        if (user.MustChangePassword || user.RecoveryCodeHash is null)
        {
            recoveryCode = SecretGenerator.RecoveryCode();
            user.RecoveryCodeHash = hasher.Hash(SecretGenerator.NormalizeRecoveryCode(recoveryCode));
        }
        user.MustChangePassword = false;

        AddHistory(db, user.Id, user.Username, LoginEventType.PasswordChanged, null);
        db.AuditLogs.Add(new AuditLog
        {
            AtUtc = Now, UserId = user.Id, Action = "user.password_changed",
            EntityName = nameof(User), EntityId = user.Id.ToString()
        });
        await db.SaveChangesAsync(ct);
        return new PasswordChangeResult(PasswordChangeStatus.Success, recoveryCode);
    }

    public async Task<RecoveryResult> ResetWithRecoveryCodeAsync(string username, string recoveryCode,
        string newPassword, CancellationToken ct = default)
    {
        var name = (username ?? string.Empty).Trim();
        await using var db = await factory.CreateDbContextAsync(ct);
        var user = await db.Users.FirstOrDefaultAsync(u => u.Username == name, ct);
        var normalized = SecretGenerator.NormalizeRecoveryCode(recoveryCode);

        if (user is null || !user.IsActive || user.RecoveryCodeHash is null)
        {
            hasher.Verify(normalized, _dummyHash.Value);
            return new RecoveryResult(RecoveryStatus.InvalidCredentials);
        }

        if (IsLocked(user, out var remaining))
            return new RecoveryResult(RecoveryStatus.LockedOut, LockoutRemaining: remaining);

        if (normalized.Length == 0 || !hasher.Verify(normalized, user.RecoveryCodeHash))
        {
            var lockedNow = RegisterFailure(db, user, "كود استرجاع خاطئ");
            await db.SaveChangesAsync(ct);
            return lockedNow
                ? new RecoveryResult(RecoveryStatus.LockedOut, LockoutRemaining: LockoutDuration)
                : new RecoveryResult(RecoveryStatus.InvalidCredentials);
        }

        var policy = PasswordPolicy.Validate(newPassword, user.Username);
        if (policy is not null)
            return new RecoveryResult(RecoveryStatus.PolicyViolation, Message: policy);

        var newCode = SecretGenerator.RecoveryCode();
        user.PasswordHash = hasher.Hash(newPassword);
        user.RecoveryCodeHash = hasher.Hash(SecretGenerator.NormalizeRecoveryCode(newCode)); // الكود القديم يُلغى
        user.MustChangePassword = false;
        user.FailedLoginCount = 0;
        user.LockoutEndUtc = null;

        AddHistory(db, user.Id, user.Username, LoginEventType.PasswordReset, "عبر كود الاسترجاع");
        db.AuditLogs.Add(new AuditLog
        {
            AtUtc = Now, UserId = user.Id, Action = "user.password_reset_by_recovery_code",
            EntityName = nameof(User), EntityId = user.Id.ToString()
        });
        await db.SaveChangesAsync(ct);
        logger.LogWarning("Password reset via recovery code for {Username}", user.Username);
        return new RecoveryResult(RecoveryStatus.Success, newCode);
    }

    private bool IsLocked(User user, out TimeSpan remaining)
    {
        remaining = TimeSpan.Zero;
        if (user.LockoutEndUtc is { } end && end > Now)
        {
            remaining = end - Now;
            return true;
        }
        return false;
    }

    /// <returns>true إذا تم قفل الحساب بهذه المحاولة.</returns>
    private bool RegisterFailure(AppDbContext db, User user, string note)
    {
        user.FailedLoginCount++;
        AddHistory(db, user.Id, user.Username, LoginEventType.FailedLogin, note);
        if (user.FailedLoginCount < MaxFailedAttempts) return false;

        user.FailedLoginCount = 0;
        user.LockoutEndUtc = Now + LockoutDuration;
        AddHistory(db, user.Id, user.Username, LoginEventType.Lockout, $"قفل لمدة {LockoutDuration.TotalMinutes:0} دقائق");
        logger.LogWarning("User {Username} locked out", user.Username);
        return true;
    }

    private void AddHistory(AppDbContext db, int? userId, string username, LoginEventType type, string? note) =>
        db.LoginHistories.Add(new LoginHistory
        {
            AtUtc = Now, UserId = userId, Username = username, EventType = type, Note = note
        });
}
