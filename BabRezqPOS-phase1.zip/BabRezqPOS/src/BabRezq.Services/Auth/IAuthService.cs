namespace BabRezq.Services.Auth;

public interface IAuthService
{
    Task<LoginResult> LoginAsync(string username, string password, CancellationToken ct = default);
    Task LogoutAsync(int userId, CancellationToken ct = default);
    Task<PasswordChangeResult> ChangePasswordAsync(int userId, string currentPassword, string newPassword, CancellationToken ct = default);
    Task<RecoveryResult> ResetWithRecoveryCodeAsync(string username, string recoveryCode, string newPassword, CancellationToken ct = default);
}
