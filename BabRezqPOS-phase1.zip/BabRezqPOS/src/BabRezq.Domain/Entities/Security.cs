namespace BabRezq.Domain.Entities;

public class Role : EntityBase
{
    public string Name { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public bool IsSystem { get; set; }
    public ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
    public ICollection<User> Users { get; set; } = new List<User>();
}

public class Permission : EntityBase
{
    public string Code { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string GroupName { get; set; } = string.Empty;
}

public class RolePermission
{
    public int RoleId { get; set; }
    public Role Role { get; set; } = null!;
    public int PermissionId { get; set; }
    public Permission Permission { get; set; } = null!;
}

public class User : EntityBase
{
    public string Username { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    /// <summary>PBKDF2 hash فقط؛ لا تُخزَّن كلمة المرور الصريحة أبدًا.</summary>
    public string PasswordHash { get; set; } = string.Empty;
    /// <summary>Hash لكود الاسترجاع (الكود نفسه يُعرض مرة واحدة فقط).</summary>
    public string? RecoveryCodeHash { get; set; }
    public int RoleId { get; set; }
    public Role Role { get; set; } = null!;
    public bool IsActive { get; set; } = true;
    public bool MustChangePassword { get; set; }
    public int FailedLoginCount { get; set; }
    public DateTime? LockoutEndUtc { get; set; }
    public DateTime? LastLoginAtUtc { get; set; }
}

public enum LoginEventType
{
    Login,
    Logout,
    FailedLogin,
    Lockout,
    PasswordChanged,
    PasswordReset
}

public class LoginHistory
{
    public long Id { get; set; }
    public DateTime AtUtc { get; set; }
    public int? UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public LoginEventType EventType { get; set; }
    public string? Note { get; set; }
}

public class AuditLog
{
    public long Id { get; set; }
    public DateTime AtUtc { get; set; }
    public int? UserId { get; set; }
    public string Action { get; set; } = string.Empty;
    public string? EntityName { get; set; }
    public string? EntityId { get; set; }
    public string? Details { get; set; }
}
