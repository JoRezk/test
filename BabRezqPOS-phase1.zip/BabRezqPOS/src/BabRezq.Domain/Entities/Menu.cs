namespace BabRezq.Domain.Entities;

public class Category : EntityBase
{
    public string Name { get; set; } = string.Empty;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public ICollection<Product> Products { get; set; } = new List<Product>();
}

public class Product : EntityBase
{
    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Notes { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public ICollection<ProductPrice> Prices { get; set; } = new List<ProductPrice>();
}

/// <summary>
/// سعر صنف بحجم/نوع معيّن (مثل: كيلو، نصف، ربع، صغير، كبير). الصنف ذو السعر الواحد يكون VariantName فارغًا.
/// السعر بالقروش.
/// </summary>
public class ProductPrice : EntityBase
{
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
    public string VariantName { get; set; } = string.Empty;
    public long PriceMinor { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; } = true;
}

public class DeliveryZone : EntityBase
{
    public string Name { get; set; } = string.Empty;
    public long FeeMinor { get; set; }
    public bool IsActive { get; set; } = true;
}

public class PaymentMethod : EntityBase
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public bool IsSystem { get; set; }
    public bool OpensDrawer { get; set; }
}

public class AppSetting
{
    public string Key { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public DateTime UpdatedAtUtc { get; set; }
}
