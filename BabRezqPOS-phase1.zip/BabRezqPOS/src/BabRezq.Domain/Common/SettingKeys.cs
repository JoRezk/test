namespace BabRezq.Domain.Common;

public static class SettingKeys
{
    public const string RestaurantName = "Restaurant.Name";
    public const string RestaurantAddress = "Restaurant.Address";
    public const string RestaurantPhone = "Restaurant.Phone";
    public const string Currency = "Currency";

    public const string TaxEnabled = "Tax.Enabled";
    public const string TaxName = "Tax.Name";
    public const string TaxRatePercent = "Tax.RatePercent";
    public const string ServiceEnabled = "Service.Enabled";
    public const string ServiceRatePercent = "Service.RatePercent";

    public const string ReceiptFooter = "Receipt.Footer";
    public const string MenuSeeded = "System.MenuSeeded";
}
