using System.Globalization;

namespace BabRezq.Domain.Common;

/// <summary>
/// كل المبالغ المالية تُخزَّن كأعداد صحيحة بالقروش (piasters) لتجنب أخطاء الكسور العشرية.
/// 1 جنيه = 100 قرش.
/// </summary>
public static class Money
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    public static long ToMinor(decimal egp) =>
        decimal.ToInt64(decimal.Round(egp * 100m, 0, MidpointRounding.AwayFromZero));

    public static decimal ToDecimal(long minor) => minor / 100m;

    /// <summary>نسبة مئوية من مبلغ بالقروش، بتقريب بعيدًا عن الصفر.</summary>
    public static long ApplyPercent(long amountMinor, decimal percent) =>
        decimal.ToInt64(decimal.Round(amountMinor * percent / 100m, 0, MidpointRounding.AwayFromZero));

    public static string Format(long minor)
    {
        var negative = minor < 0;
        var abs = Math.Abs(minor);
        var whole = abs / 100;
        var frac = abs % 100;
        var text = frac == 0
            ? whole.ToString("N0", Inv)
            : whole.ToString("N0", Inv) + "." + frac.ToString("00", Inv);
        return (negative ? "-" : "") + text + " ج.م";
    }
}
