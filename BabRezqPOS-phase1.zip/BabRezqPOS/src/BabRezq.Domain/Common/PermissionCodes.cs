namespace BabRezq.Domain.Common;

public static class PermissionCodes
{
    public const string PosSell = "pos.sell";
    public const string PosDiscount = "pos.discount";
    public const string PosHold = "pos.hold";
    public const string InvoicesView = "invoices.view";
    public const string InvoicesReprint = "invoices.reprint";
    public const string InvoicesCancel = "invoices.cancel";
    public const string ReturnsCreate = "returns.create";
    public const string CashShift = "cash.shift";
    public const string CashManage = "cash.manage";
    public const string DrawerOpen = "drawer.open";
    public const string ReportsView = "reports.view";
    public const string InventoryManage = "inventory.manage";
    public const string MenuManage = "menu.manage";
    public const string SettingsManage = "settings.manage";
    public const string UsersManage = "users.manage";
    public const string BackupManage = "backup.manage";

    public static readonly IReadOnlyList<(string Code, string Name, string Group)> All =
    [
        (PosSell, "البيع من شاشة الكاشير", "الكاشير"),
        (PosDiscount, "منح خصم", "الكاشير"),
        (PosHold, "تعليق واسترجاع الطلبات", "الكاشير"),
        (InvoicesView, "عرض الفواتير السابقة", "الفواتير"),
        (InvoicesReprint, "إعادة طباعة فاتورة", "الفواتير"),
        (InvoicesCancel, "إلغاء فاتورة", "الفواتير"),
        (ReturnsCreate, "تسجيل مرتجع", "المرتجعات"),
        (CashShift, "فتح وإغلاق وردية الكاشير", "النقدية"),
        (CashManage, "إدارة حركة النقدية والمصروفات", "النقدية"),
        (DrawerOpen, "فتح درج النقدية يدويًا", "النقدية"),
        (ReportsView, "عرض التقارير", "التقارير"),
        (InventoryManage, "إدارة المخزون والمشتريات", "المخزون"),
        (MenuManage, "تعديل المنيو والأسعار", "الإعدادات"),
        (SettingsManage, "تعديل إعدادات البرنامج والطابعة", "الإعدادات"),
        (UsersManage, "إدارة المستخدمين والصلاحيات", "الإعدادات"),
        (BackupManage, "النسخ الاحتياطي والاستعادة", "الإعدادات"),
    ];

    /// <summary>الصلاحيات الافتراضية لدور الكاشير عند إنشائه لأول مرة.</summary>
    public static readonly IReadOnlyList<string> CashierDefaults =
        [PosSell, PosHold, InvoicesView, CashShift];
}
