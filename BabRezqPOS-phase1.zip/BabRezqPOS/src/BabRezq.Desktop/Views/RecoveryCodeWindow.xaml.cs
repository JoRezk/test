using System.IO;
using System.Text;
using System.ComponentModel;
using System.Windows;
using Microsoft.Win32;

namespace BabRezq.Desktop.Views;

public partial class RecoveryCodeWindow : Window
{
    private readonly string _code;
    private bool _confirmed;

    public RecoveryCodeWindow(string code)
    {
        _code = code;
        InitializeComponent();
        CodeBox.Text = code;
    }

    private void OnCopyClick(object sender, RoutedEventArgs e)
    {
        try { Clipboard.SetText(_code); }
        catch (System.Runtime.InteropServices.COMException) { MessageBox.Show("تعذر النسخ، اكتب الكود يدويًا."); }
    }

    private void OnSaveFileClick(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog
        {
            FileName = "BabRezq-recovery-code.txt",
            Filter = "ملف نصي (*.txt)|*.txt"
        };
        if (dialog.ShowDialog(this) != true) return;
        File.WriteAllText(dialog.FileName,
            $"باب رزق POS - كود استرجاع كلمة المرور\r\n{_code}\r\nاحتفظ بهذا الملف في مكان آمن.", Encoding.UTF8);
    }

    private void OnSavedChanged(object sender, RoutedEventArgs e) =>
        ContinueButton.IsEnabled = SavedCheck.IsChecked == true;

    private void OnContinueClick(object sender, RoutedEventArgs e)
    {
        _confirmed = true;
        DialogResult = true;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        // لا يُغلق قبل تأكيد حفظ الكود
        if (!_confirmed) e.Cancel = true;
        base.OnClosing(e);
    }
}
