using System.Windows;
using BabRezq.Data.Infrastructure;
using BabRezq.Domain.Common;
using BabRezq.Services.Auth;
using BabRezq.Services.Menu;

namespace BabRezq.Desktop.Views;

public partial class MainWindow : Window
{
    private readonly IMenuQueryService _menu;
    private readonly AppPaths _paths;

    public MainWindow(IMenuQueryService menu, AppPaths paths, AuthenticatedUser user)
    {
        _menu = menu;
        _paths = paths;
        InitializeComponent();
        UserText.Text = $"{user.FullName}  ({user.RoleName})";
        Loaded += async (_, _) => await LoadAsync();
    }

    private async Task LoadAsync()
    {
        try
        {
            var rows = await _menu.GetFlatMenuAsync();
            MenuGrid.ItemsSource = rows.Select(r => new
            {
                r.Category,
                r.Product,
                Variant = r.Variant,
                Price = Money.Format(r.PriceMinor),
                Status = r.Active ? "متاح" : "موقوف"
            }).ToList();

            StatsText.Text =
                $"الأقسام: {rows.Select(r => r.Category).Distinct().Count()}\n" +
                $"الأصناف: {rows.Select(r => (r.Category, r.Product)).Distinct().Count()}\n" +
                $"الأسعار: {rows.Count}\n\n" +
                $"قاعدة البيانات:\n{_paths.DbPath}";
        }
        catch (Exception ex)
        {
            Serilog.Log.Error(ex, "Failed to load menu");
            StatsText.Text = "تعذر تحميل المنيو. راجع ملف السجل.";
        }
    }

    private void OnLogoutClick(object sender, RoutedEventArgs e) => DialogResult = true;

    private void OnExitClick(object sender, RoutedEventArgs e) => DialogResult = false;
}
