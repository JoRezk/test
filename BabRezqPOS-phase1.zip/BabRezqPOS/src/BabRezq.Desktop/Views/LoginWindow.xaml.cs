using System.Windows;
using BabRezq.Services.Auth;

namespace BabRezq.Desktop.Views;

public partial class LoginWindow : Window
{
    private readonly IAuthService _auth;

    public AuthenticatedUser? User { get; private set; }

    public LoginWindow(IAuthService auth)
    {
        _auth = auth;
        InitializeComponent();
        Loaded += (_, _) => UsernameBox.Focus();
    }

    private async void OnLoginClick(object sender, RoutedEventArgs e)
    {
        ErrorText.Visibility = Visibility.Collapsed;
        if (string.IsNullOrWhiteSpace(UsernameBox.Text) || PasswordBox.Password.Length == 0)
        {
            ShowError("أدخل اسم المستخدم وكلمة المرور.");
            return;
        }

        LoginButton.IsEnabled = false; // يمنع الضغط المتكرر
        try
        {
            var result = await _auth.LoginAsync(UsernameBox.Text, PasswordBox.Password);
            switch (result.Status)
            {
                case LoginStatus.Success:
                    User = result.User;
                    DialogResult = true;
                    return;
                case LoginStatus.LockedOut:
                    var minutes = Math.Max(1, (int)Math.Ceiling(result.LockoutRemaining?.TotalMinutes ?? 5));
                    ShowError($"تم قفل الحساب مؤقتًا بسبب محاولات خاطئة. حاول بعد {minutes} دقيقة.");
                    break;
                case LoginStatus.Inactive:
                    ShowError("هذا الحساب موقوف. راجع المدير.");
                    break;
                default:
                    ShowError("اسم المستخدم أو كلمة المرور غير صحيحة.");
                    break;
            }
            PasswordBox.Clear();
            PasswordBox.Focus();
        }
        catch (Exception ex)
        {
            Serilog.Log.Error(ex, "Login failed unexpectedly");
            ShowError("حدث خطأ أثناء تسجيل الدخول. راجع ملف السجل.");
        }
        finally
        {
            LoginButton.IsEnabled = true;
        }
    }

    private void OnForgotClick(object sender, RoutedEventArgs e)
    {
        new RecoveryResetWindow(_auth) { Owner = this }.ShowDialog();
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}
