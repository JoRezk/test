using System.Windows;
using BabRezq.Services.Auth;

namespace BabRezq.Desktop.Views;

public partial class ChangePasswordWindow : Window
{
    private readonly IAuthService _auth;
    private readonly AuthenticatedUser _user;

    public ChangePasswordWindow(IAuthService auth, AuthenticatedUser user)
    {
        _auth = auth;
        _user = user;
        InitializeComponent();
        Loaded += (_, _) => CurrentBox.Focus();
    }

    private async void OnSaveClick(object sender, RoutedEventArgs e)
    {
        ErrorText.Visibility = Visibility.Collapsed;
        if (NewBox.Password != ConfirmBox.Password)
        {
            ShowError("تأكيد كلمة المرور لا يطابق كلمة المرور الجديدة.");
            return;
        }

        SaveButton.IsEnabled = false;
        try
        {
            var result = await _auth.ChangePasswordAsync(_user.Id, CurrentBox.Password, NewBox.Password);
            if (result.Status != PasswordChangeStatus.Success)
            {
                ShowError(result.Message ?? "تعذر تغيير كلمة المرور.");
                return;
            }

            if (result.RecoveryCode is not null)
                new RecoveryCodeWindow(result.RecoveryCode) { Owner = this }.ShowDialog();

            DialogResult = true;
        }
        catch (Exception ex)
        {
            Serilog.Log.Error(ex, "Change password failed");
            ShowError("حدث خطأ أثناء حفظ كلمة المرور. راجع ملف السجل.");
        }
        finally
        {
            SaveButton.IsEnabled = true;
        }
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}
