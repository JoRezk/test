using System.Windows;
using BabRezq.Services.Auth;

namespace BabRezq.Desktop.Views;

public partial class RecoveryResetWindow : Window
{
    private readonly IAuthService _auth;

    public RecoveryResetWindow(IAuthService auth)
    {
        _auth = auth;
        InitializeComponent();
        Loaded += (_, _) => UsernameBox.Focus();
    }

    private async void OnResetClick(object sender, RoutedEventArgs e)
    {
        ErrorText.Visibility = Visibility.Collapsed;
        if (NewBox.Password != ConfirmBox.Password)
        {
            ShowError("تأكيد كلمة المرور لا يطابق كلمة المرور الجديدة.");
            return;
        }

        ResetButton.IsEnabled = false;
        try
        {
            var result = await _auth.ResetWithRecoveryCodeAsync(UsernameBox.Text, CodeBox.Text, NewBox.Password);
            switch (result.Status)
            {
                case RecoveryStatus.Success:
                    // الكود القديم أُلغي وصدر كود جديد يجب حفظه
                    new RecoveryCodeWindow(result.NewRecoveryCode!) { Owner = this }.ShowDialog();
                    MessageBox.Show("تم تغيير كلمة المرور. يمكنك الدخول الآن.", "باب رزق POS",
                        MessageBoxButton.OK, MessageBoxImage.Information,
                        MessageBoxResult.OK, MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
                    DialogResult = true;
                    return;
                case RecoveryStatus.PolicyViolation:
                    ShowError(result.Message ?? "كلمة المرور الجديدة غير مقبولة.");
                    break;
                case RecoveryStatus.LockedOut:
                    ShowError("تم قفل الحساب مؤقتًا بسبب محاولات خاطئة. حاول لاحقًا.");
                    break;
                default:
                    ShowError("اسم المستخدم أو كود الاسترجاع غير صحيح.");
                    break;
            }
        }
        catch (Exception ex)
        {
            Serilog.Log.Error(ex, "Recovery reset failed");
            ShowError("حدث خطأ أثناء إعادة التعيين. راجع ملف السجل.");
        }
        finally
        {
            ResetButton.IsEnabled = true;
        }
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}
