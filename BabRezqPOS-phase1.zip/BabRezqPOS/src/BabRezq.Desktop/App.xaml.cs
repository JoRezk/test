using System.IO;
using System.Security.Principal;
using System.Text;
using System.Windows;
using BabRezq.Data.Infrastructure;
using BabRezq.Desktop.Views;
using BabRezq.Services;
using BabRezq.Services.Auth;
using BabRezq.Services.Menu;
using BabRezq.Services.Seeding;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;

namespace BabRezq.Desktop;

public partial class App : Application
{
    private Mutex? _mutex;
    private ServiceProvider? _provider;
    private AppPaths? _paths;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
        DispatcherUnhandledException += (_, args) =>
        {
            Log.Error(args.Exception, "Unhandled UI exception");
            MessageBox.Show("حدث خطأ غير متوقع وتم تسجيله في ملف السجل.\n" + args.Exception.Message,
                "باب رزق POS", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };

        try
        {
            await RunAsync(e.Args);
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "Fatal startup error");
            MessageBox.Show("تعذر تشغيل البرنامج:\n" + ex.Message, "باب رزق POS",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _provider?.Dispose();
            _mutex?.Dispose();
            Log.CloseAndFlush();
            Shutdown();
        }
    }

    private async Task RunAsync(string[] args)
    {
        _mutex = new Mutex(true, @"Global\BabRezqPOS.SingleInstance", out var createdNew);
        if (!createdNew)
        {
            MessageBox.Show("البرنامج يعمل بالفعل على هذا الجهاز.", "باب رزق POS",
                MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        _paths = AppPaths.Resolve();
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(Path.Combine(_paths.LogsDir, "babrezq-.log"),
                rollingInterval: RollingInterval.Day, retainedFileCountLimit: 30)
            .CreateLogger();
        Log.Information("BabRezq POS starting. Data dir: {Dir}", _paths.DataDir);

        var services = new ServiceCollection();
        services.AddSingleton(_paths);
        services.AddLogging(b => b.AddSerilog(Log.Logger, dispose: false));
        services.AddBabRezqData(_paths.DbPath);
        services.AddBabRezqServices();
        _provider = services.BuildServiceProvider();

        var initializer = _provider.GetRequiredService<DatabaseInitializer>();
        var init = await initializer.InitializeAsync();

        if (args.Contains("--reset-admin"))
        {
            await ResetAdminAsync(initializer, init);
            return;
        }

        if (init.FirstRunTempPassword is not null)
            ShowCredentials(init.FirstRunUsername!, init.FirstRunTempPassword, firstRun: true);

        await RunSessionLoopAsync();
    }

    private async Task ResetAdminAsync(DatabaseInitializer initializer, InitializationResult init)
    {
        if (init.FirstRunTempPassword is not null)
        {
            // قاعدة جديدة: تم إنشاء المدير للتو، لا حاجة لإعادة تعيين.
            ShowCredentials(init.FirstRunUsername!, init.FirstRunTempPassword, firstRun: true);
            return;
        }

        using var identity = WindowsIdentity.GetCurrent();
        if (!new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator))
        {
            MessageBox.Show("إعادة تعيين كلمة مرور المدير تتطلب تشغيل البرنامج كمسؤول Windows (Run as administrator).",
                "باب رزق POS", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var confirm = MessageBox.Show(
            "سيتم إعادة تعيين كلمة مرور المدير إلى كلمة مؤقتة جديدة، ولن تعمل كلمة المرور القديمة وكود الاسترجاع القديم.\nهل تريد المتابعة؟",
            "إعادة تعيين كلمة مرور المدير", MessageBoxButton.YesNo, MessageBoxImage.Warning);
        if (confirm != MessageBoxResult.Yes) return;

        var result = await initializer.ResetPrimaryManagerAsync();
        if (result is null)
        {
            MessageBox.Show("لا يوجد حساب مدير في قاعدة البيانات.", "باب رزق POS",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }
        ShowCredentials(result.Username, result.TempPassword, firstRun: false);
    }

    private void ShowCredentials(string username, string tempPassword, bool firstRun)
    {
        var text = new StringBuilder()
            .AppendLine("باب رزق POS - بيانات الدخول المؤقتة")
            .AppendLine($"اسم المستخدم: {username}")
            .AppendLine($"كلمة المرور المؤقتة: {tempPassword}")
            .AppendLine("ستُطلب منك كلمة مرور جديدة عند أول دخول. احذف هذا الملف بعد ذلك (يُحذف تلقائيًا بعد تغيير كلمة المرور).")
            .ToString();
        try { File.WriteAllText(_paths!.FirstRunFile, text, Encoding.UTF8); }
        catch (IOException ex) { Log.Warning(ex, "Could not write credentials file"); }

        MessageBox.Show(
            (firstRun ? "تم إنشاء حساب المدير الافتراضي.\n\n" : "تمت إعادة تعيين كلمة مرور المدير.\n\n") +
            $"اسم المستخدم: {username}\nكلمة المرور المؤقتة: {tempPassword}\n\n" +
            "ستُطلب منك كلمة مرور جديدة عند الدخول.\n" +
            $"نسخة من هذه البيانات محفوظة في:\n{_paths!.FirstRunFile}",
            "بيانات الدخول المؤقتة", MessageBoxButton.OK, MessageBoxImage.Information,
            MessageBoxResult.OK, MessageBoxOptions.RtlReading | MessageBoxOptions.RightAlign);
    }

    private async Task RunSessionLoopAsync()
    {
        var auth = _provider!.GetRequiredService<IAuthService>();
        var menu = _provider.GetRequiredService<IMenuQueryService>();

        while (true)
        {
            var login = new LoginWindow(auth);
            if (login.ShowDialog() != true || login.User is null) return;
            var user = login.User;

            if (user.MustChangePassword)
            {
                var change = new ChangePasswordWindow(auth, user);
                if (change.ShowDialog() != true)
                {
                    await auth.LogoutAsync(user.Id);
                    continue;
                }
                try { if (File.Exists(_paths!.FirstRunFile)) File.Delete(_paths.FirstRunFile); }
                catch (IOException ex) { Log.Warning(ex, "Could not delete credentials file"); }
                user = user with { MustChangePassword = false };
            }

            var main = new MainWindow(menu, _paths!, user);
            var loggedOut = main.ShowDialog() == true;
            await auth.LogoutAsync(user.Id);
            if (!loggedOut) return;
        }
    }
}
