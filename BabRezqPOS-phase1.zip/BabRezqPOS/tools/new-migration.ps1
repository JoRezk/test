# توليد Migration جديد لقاعدة البيانات. شغّله من جذر المشروع على Windows:
#   .\tools\new-migration.ps1 InitialCreate
param([Parameter(Mandatory = $true)][string]$Name)

$ErrorActionPreference = 'Stop'
dotnet tool update --global dotnet-ef --version 10.0.0
dotnet ef migrations add $Name `
    --project src/BabRezq.Data `
    --startup-project src/BabRezq.Desktop `
    --output-dir Migrations
