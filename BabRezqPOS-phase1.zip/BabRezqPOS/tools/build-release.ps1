# بناء نسخة EXE قابلة للتشغيل (self-contained) على Windows 10/11 x64:
#   .\tools\build-release.ps1
$ErrorActionPreference = 'Stop'
dotnet test tests/BabRezq.Tests -c Release
dotnet publish src/BabRezq.Desktop -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
Write-Host "تم. الملف: publish\BabRezqPOS.exe"
